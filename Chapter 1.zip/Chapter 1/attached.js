document.write("This came from the attached Javascript file");
document.write("<br/>Some think that attaching js is the best way to use it with HTML");